export interface TimeEdit {
    columnheaders: string[];
    reservationlimit: number;
    reservationcount: number;
    id: number;
    startdate: string;
    starttime: string;
    enddate: string;
    endtime: string;
    columns: string [];
}
